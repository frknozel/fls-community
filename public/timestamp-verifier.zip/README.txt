FLS timestamp verifier

Run python3 verify-timestamp.py --help for verification options.
The matching tsa_core.py is supplied beside the command. Install the Python
dependencies required by that command in your own verification environment.
No account, provider SDK, private key or archive data is included.
FLS project source is Apache-2.0; see the repository LICENSE and NOTICE.
